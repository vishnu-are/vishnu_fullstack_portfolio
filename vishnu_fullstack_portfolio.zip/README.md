# Vishnu Are · Portfolio

Static portfolio site (plain HTML and CSS, no build step), published with GitHub Pages at https://vishnu-are.github.io/vishnu_fullstack_portfolio/.
